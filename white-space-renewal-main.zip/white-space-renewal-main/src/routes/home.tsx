import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Inicio — Red Social" },
      {
        name: "description",
        content: "Tu feed personal. Conecta, comparte y construye.",
      },
    ],
  }),
  component: HomePage,
});

type Post = {
  id: string;
  author: string;
  handle: string;
  time: string;
  content: string;
  likes: number;
  comments: number;
};

const SEED_POSTS: Post[] = [
  {
    id: "1",
    author: "Lucía Romero",
    handle: "lucia",
    time: "hace 5 min",
    content:
      "Empezando el día con café y un cuaderno en blanco. Las mejores ideas siempre llegan así.",
    likes: 24,
    comments: 4,
  },
  {
    id: "2",
    author: "Mateo Vidal",
    handle: "mateo",
    time: "hace 1 h",
    content:
      "Acabo de publicar mi primer ensayo aquí. Sin algoritmos, sin métricas vanidosas — solo escribir.",
    likes: 58,
    comments: 12,
  },
  {
    id: "3",
    author: "Sofía Martín",
    handle: "sofia",
    time: "hace 3 h",
    content: "Diseño minimalista no es ausencia. Es intención.",
    likes: 142,
    comments: 21,
  },
];

function HomePage() {
  const [draft, setDraft] = useState("");
  const [posts, setPosts] = useState<Post[]>(SEED_POSTS);

  const publish = () => {
    const text = draft.trim();
    if (!text) return;
    setPosts((p) => [
      {
        id: crypto.randomUUID(),
        author: "Tú",
        handle: "tu",
        time: "ahora",
        content: text,
        likes: 0,
        comments: 0,
      },
      ...p,
    ]);
    setDraft("");
  };

  return (
    <main
      className="min-h-screen w-full bg-background text-foreground antialiased"
      style={{ fontFamily: "var(--font-sans)" }}
    >
      <TopNav />

      <div className="mx-auto grid w-full max-w-[1200px] grid-cols-1 gap-12 px-6 pb-24 pt-10 sm:px-10 md:grid-cols-[200px_minmax(0,1fr)_240px]">
        <Sidebar />

        <section className="min-w-0">
          <Composer value={draft} onChange={setDraft} onPublish={publish} />

          <div className="mt-10">
            <SectionLabel>Tu feed</SectionLabel>
            <ul className="mt-6 divide-y divide-[color:var(--hairline)]">
              {posts.map((p) => (
                <PostItem key={p.id} post={p} />
              ))}
            </ul>
          </div>
        </section>

        <RightRail />
      </div>
    </main>
  );
}

function TopNav() {
  return (
    <header className="sticky top-0 z-10 w-full border-b border-[color:var(--hairline)] bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 w-full max-w-[1200px] items-center justify-between px-6 sm:px-10">
        <Link to="/home" className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full bg-foreground" />
          <span className="text-[13px] font-medium tracking-tight">
            Red Social
          </span>
        </Link>

        <div className="hidden flex-1 justify-center px-12 md:flex">
          <div className="relative w-full max-w-sm">
            <input
              placeholder="Buscar"
              className="h-9 w-full rounded-md border border-[color:var(--hairline)] bg-transparent pl-8 pr-3 text-[13px] outline-none transition-colors placeholder:text-[color:var(--subtle)]/70 focus:border-foreground"
            />
            <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[color:var(--subtle)]">
              <SearchIcon />
            </span>
          </div>
        </div>

        <div className="flex items-center gap-5 text-[color:var(--subtle)]">
          <button className="transition-colors hover:text-foreground" aria-label="Notificaciones">
            <BellIcon />
          </button>
          <Link
            to="/"
            className="text-[12px] tracking-tight transition-colors hover:text-foreground"
          >
            Salir
          </Link>
          <div className="h-7 w-7 rounded-full bg-foreground text-background flex items-center justify-center text-[11px] font-medium">
            T
          </div>
        </div>
      </div>
    </header>
  );
}

function Sidebar() {
  const items: { label: string; to?: "/home" | "/rooms"; active?: boolean }[] = [
    { label: "Inicio", to: "/home", active: true },
    { label: "Salas", to: "/rooms" },
    { label: "Explorar" },
    { label: "Mensajes" },
    { label: "Guardados" },
    { label: "Perfil" },
    { label: "Ajustes" },
  ];
  return (
    <aside className="hidden md:block">
      <SectionLabel>Menú</SectionLabel>
      <nav className="mt-6 space-y-1">
        {items.map((it) => {
          const cls =
            "group flex w-full items-center justify-between py-2 text-left text-[14px] transition-colors " +
            (it.active
              ? "text-foreground"
              : "text-[color:var(--subtle)] hover:text-foreground");
          const inner = (
            <>
              <span>{it.label}</span>
              <span
                aria-hidden
                className={
                  "h-px bg-foreground transition-all duration-300 " +
                  (it.active ? "w-6" : "w-0 group-hover:w-4")
                }
              />
            </>
          );
          return it.to ? (
            <Link key={it.label} to={it.to} className={cls}>
              {inner}
            </Link>
          ) : (
            <button key={it.label} className={cls}>
              {inner}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}

function Composer({
  value,
  onChange,
  onPublish,
}: {
  value: string;
  onChange: (v: string) => void;
  onPublish: () => void;
}) {
  const remaining = 280 - value.length;
  return (
    <div className="border-b border-[color:var(--hairline)] pb-6">
      <SectionLabel>Comparte algo</SectionLabel>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="¿En qué estás pensando?"
        rows={3}
        maxLength={280}
        className="mt-4 block w-full resize-none border-0 bg-transparent text-[18px] leading-relaxed tracking-tight outline-none placeholder:text-[color:var(--subtle)]/70"
      />
      <div className="mt-3 flex items-center justify-between">
        <span
          className={
            "text-[11px] tracking-tight " +
            (remaining < 30
              ? "text-foreground"
              : "text-[color:var(--subtle)]")
          }
        >
          {remaining} caracteres
        </span>
        <button
          onClick={onPublish}
          disabled={!value.trim()}
          className="group inline-flex h-9 items-center gap-2 rounded-md bg-foreground px-4 text-[12px] font-medium tracking-tight text-background transition-all duration-200 hover:opacity-90 active:scale-[0.99] disabled:opacity-30"
        >
          Publicar
          <span
            aria-hidden
            className="transition-transform duration-200 group-hover:translate-x-0.5"
          >
            →
          </span>
        </button>
      </div>
    </div>
  );
}

function PostItem({ post }: { post: Post }) {
  const [liked, setLiked] = useState(false);
  const likeCount = post.likes + (liked ? 1 : 0);
  return (
    <li className="py-7">
      <div className="flex items-start gap-4">
        <div className="mt-0.5 h-9 w-9 flex-shrink-0 rounded-full border border-[color:var(--hairline)] bg-background flex items-center justify-center text-[12px] font-medium">
          {post.author.charAt(0)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2 text-[13px]">
            <span className="font-medium tracking-tight">{post.author}</span>
            <span className="text-[color:var(--subtle)]">@{post.handle}</span>
            <span className="text-[color:var(--subtle)]">·</span>
            <span className="text-[color:var(--subtle)]">{post.time}</span>
          </div>
          <p className="mt-2 text-[15px] leading-relaxed tracking-tight text-foreground">
            {post.content}
          </p>
          <div className="mt-4 flex items-center gap-7 text-[12px] text-[color:var(--subtle)]">
            <button
              onClick={() => setLiked((l) => !l)}
              className={
                "inline-flex items-center gap-1.5 transition-colors " +
                (liked ? "text-foreground" : "hover:text-foreground")
              }
            >
              <HeartIcon filled={liked} />
              {likeCount}
            </button>
            <button className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground">
              <CommentIcon />
              {post.comments}
            </button>
            <button className="inline-flex items-center gap-1.5 transition-colors hover:text-foreground">
              <ShareIcon />
              Compartir
            </button>
          </div>
        </div>
      </div>
    </li>
  );
}

function RightRail() {
  const trending = [
    { tag: "diseño", count: "1.2k notas" },
    { tag: "minimalismo", count: "842 notas" },
    { tag: "escritura", count: "612 notas" },
    { tag: "tipografía", count: "438 notas" },
  ];
  const suggestions = [
    { name: "Andrés Peña", handle: "andres" },
    { name: "Clara Ibáñez", handle: "clara" },
    { name: "Diego Soto", handle: "diego" },
  ];
  return (
    <aside className="hidden md:block">
      <SectionLabel>Tendencias</SectionLabel>
      <ul className="mt-6 space-y-4">
        {trending.map((t) => (
          <li key={t.tag} className="group cursor-pointer">
            <div className="text-[14px] tracking-tight transition-colors group-hover:text-foreground">
              #{t.tag}
            </div>
            <div className="mt-0.5 text-[11px] text-[color:var(--subtle)]">
              {t.count}
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-12">
        <SectionLabel>Sugerencias</SectionLabel>
        <ul className="mt-6 space-y-5">
          {suggestions.map((s) => (
            <li key={s.handle} className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full border border-[color:var(--hairline)] flex items-center justify-center text-[11px] font-medium">
                {s.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[13px] tracking-tight">
                  {s.name}
                </div>
                <div className="text-[11px] text-[color:var(--subtle)]">
                  @{s.handle}
                </div>
              </div>
              <button className="text-[11px] uppercase tracking-[0.14em] text-[color:var(--subtle)] transition-colors hover:text-foreground">
                Seguir
              </button>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
      {children}
    </div>
  );
}

/* — Icons (inline, hairline) — */
function SearchIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" strokeLinecap="round" />
    </svg>
  );
}
function BellIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M6 8a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z" strokeLinejoin="round" />
      <path d="M10 19a2 2 0 0 0 4 0" strokeLinecap="round" />
    </svg>
  );
}
function HeartIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5">
      <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z" strokeLinejoin="round" />
    </svg>
  );
}
function CommentIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M4 5h16v11H8l-4 4V5Z" strokeLinejoin="round" />
    </svg>
  );
}
function ShareIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M4 12v7h16v-7" strokeLinejoin="round" />
      <path d="M12 3v13m0-13-4 4m4-4 4 4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
