import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/rooms")({
  head: () => ({
    meta: [
      { title: "Salas — Red Social" },
      {
        name: "description",
        content: "Espacios de conversación. Únete o crea tu propia sala.",
      },
    ],
  }),
  component: RoomsPage,
});

type Room = {
  id: string;
  name: string;
  topic: string;
  members: number;
  online: number;
  category: "Diseño" | "Escritura" | "Tecnología" | "Cultura";
  live?: boolean;
};

const SEED: Room[] = [
  { id: "1", name: "Estudio Tipográfico", topic: "Sobre formas, kerning y obsesiones.", members: 1284, online: 42, category: "Diseño", live: true },
  { id: "2", name: "Cuaderno Abierto", topic: "Comparte un párrafo, recibe uno.", members: 932, online: 18, category: "Escritura" },
  { id: "3", name: "Menos es más", topic: "Minimalismo aplicado al producto.", members: 2104, online: 87, category: "Diseño", live: true },
  { id: "4", name: "Café & Código", topic: "Conversaciones lentas sobre software.", members: 1567, online: 31, category: "Tecnología" },
  { id: "5", name: "Lecturas de domingo", topic: "Ensayos, novelas y descubrimientos.", members: 612, online: 9, category: "Cultura" },
  { id: "6", name: "Pixel & Papel", topic: "Donde lo digital y lo impreso conversan.", members: 488, online: 14, category: "Diseño" },
];

const CATEGORIES = ["Todas", "Diseño", "Escritura", "Tecnología", "Cultura"] as const;
type Cat = (typeof CATEGORIES)[number];

function RoomsPage() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<Cat>("Todas");
  const [rooms] = useState<Room[]>(SEED);

  const filtered = useMemo(() => {
    return rooms.filter((r) => {
      const matchCat = cat === "Todas" || r.category === cat;
      const q = query.trim().toLowerCase();
      const matchQ =
        !q ||
        r.name.toLowerCase().includes(q) ||
        r.topic.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }, [rooms, cat, query]);

  return (
    <main
      className="min-h-screen w-full bg-background text-foreground antialiased"
      style={{ fontFamily: "var(--font-sans)" }}
    >
      <TopNav />

      <div className="mx-auto w-full max-w-[1200px] px-6 pb-24 pt-12 sm:px-10">
        <Header
          query={query}
          setQuery={setQuery}
        />

        <div className="mt-10 flex flex-wrap items-center gap-x-7 gap-y-3 border-b border-[color:var(--hairline)] pb-4">
          {CATEGORIES.map((c) => (
            <CategoryTab
              key={c}
              active={cat === c}
              onClick={() => setCat(c)}
            >
              {c}
            </CategoryTab>
          ))}
        </div>

        <div className="mt-10">
          <div className="mb-6 flex items-end justify-between">
            <SectionLabel>
              {filtered.length} {filtered.length === 1 ? "sala" : "salas"}
            </SectionLabel>
            <span className="text-[11px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
              Ordenado por actividad
            </span>
          </div>

          {filtered.length === 0 ? (
            <EmptyState />
          ) : (
            <ul className="grid grid-cols-1 gap-px bg-[color:var(--hairline)] border border-[color:var(--hairline)] sm:grid-cols-2">
              {filtered.map((r) => (
                <RoomCard key={r.id} room={r} />
              ))}
            </ul>
          )}
        </div>
      </div>
    </main>
  );
}

function Header({
  query,
  setQuery,
}: {
  query: string;
  setQuery: (v: string) => void;
}) {
  return (
    <div className="flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-xl">
        <p className="mb-3 text-[11px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
          Espacios
        </p>
        <h1 className="text-[40px] font-medium leading-[1.05] tracking-[-0.02em] sm:text-[52px]">
          Salas.
        </h1>
        <p className="mt-4 max-w-md text-[15px] leading-relaxed text-[color:var(--subtle)]">
          Conversaciones en torno a una idea. Entra, escucha, escribe.
        </p>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar sala"
            className="h-10 w-64 border-0 border-b border-[color:var(--hairline)] bg-transparent pb-2 pl-6 text-[14px] outline-none transition-colors placeholder:text-[color:var(--subtle)]/60 focus:border-foreground"
          />
          <span className="pointer-events-none absolute left-0 top-1/2 -translate-y-1/2 text-[color:var(--subtle)]">
            <SearchIcon />
          </span>
        </div>
        <button className="group inline-flex h-10 items-center gap-2 rounded-md bg-foreground px-4 text-[12px] font-medium tracking-tight text-background transition-all duration-200 hover:opacity-90 active:scale-[0.99]">
          Crear sala
          <span aria-hidden className="transition-transform duration-200 group-hover:translate-x-0.5">
            +
          </span>
        </button>
      </div>
    </div>
  );
}

function CategoryTab({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={
        "relative pb-3 text-[13px] tracking-tight transition-colors " +
        (active
          ? "text-foreground"
          : "text-[color:var(--subtle)] hover:text-foreground")
      }
    >
      {children}
      <span
        aria-hidden
        className={
          "absolute -bottom-px left-0 h-px bg-foreground transition-all duration-300 " +
          (active ? "w-full" : "w-0")
        }
      />
    </button>
  );
}

function RoomCard({ room }: { room: Room }) {
  return (
    <li className="group relative bg-background p-7 transition-colors hover:bg-[color:var(--hairline)]/30">
      <div className="flex items-start justify-between">
        <span className="text-[10px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
          {room.category}
        </span>
        {room.live && (
          <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-foreground">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-foreground opacity-50" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-foreground" />
            </span>
            En vivo
          </span>
        )}
      </div>

      <h3 className="mt-6 text-[22px] font-medium tracking-[-0.01em]">
        {room.name}
      </h3>
      <p className="mt-2 max-w-md text-[14px] leading-relaxed text-[color:var(--subtle)]">
        {room.topic}
      </p>

      <div className="mt-8 flex items-center justify-between">
        <div className="flex items-center gap-5 text-[12px] text-[color:var(--subtle)]">
          <span className="inline-flex items-center gap-1.5">
            <UsersIcon />
            {formatCount(room.members)} miembros
          </span>
          <span className="inline-flex items-center gap-1.5">
            <DotIcon />
            {room.online} en línea
          </span>
        </div>

        <button className="group/btn inline-flex items-center gap-1.5 text-[12px] font-medium tracking-tight text-foreground">
          Entrar
          <span
            aria-hidden
            className="transition-transform duration-200 group-hover/btn:translate-x-0.5"
          >
            →
          </span>
        </button>
      </div>
    </li>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center border border-dashed border-[color:var(--hairline)] py-24 text-center">
      <div className="text-[13px] tracking-tight text-foreground">
        No encontramos nada por aquí.
      </div>
      <p className="mt-2 max-w-xs text-[12px] text-[color:var(--subtle)]">
        Prueba con otra búsqueda o crea tú la primera sala sobre el tema.
      </p>
    </div>
  );
}

function TopNav() {
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-10 w-full border-b border-[color:var(--hairline)] bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 w-full max-w-[1200px] items-center justify-between px-6 sm:px-10">
        <Link to="/home" className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full bg-foreground" />
          <span className="text-[13px] font-medium tracking-tight">
            Red Social
          </span>
        </Link>

        <nav className="hidden items-center gap-7 text-[13px] text-[color:var(--subtle)] md:flex">
          <Link to="/home" className="transition-colors hover:text-foreground">
            Inicio
          </Link>
          <Link
            to="/rooms"
            className="text-foreground"
          >
            Salas
          </Link>
          <span className="cursor-pointer transition-colors hover:text-foreground">
            Mensajes
          </span>
          <span className="cursor-pointer transition-colors hover:text-foreground">
            Perfil
          </span>
        </nav>

        <button
          onClick={() => navigate({ to: "/" })}
          className="text-[12px] tracking-tight text-[color:var(--subtle)] transition-colors hover:text-foreground"
        >
          Salir
        </button>
      </div>
    </header>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
      {children}
    </div>
  );
}

function formatCount(n: number) {
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return String(n);
}

/* — Icons — */
function SearchIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" strokeLinecap="round" />
    </svg>
  );
}
function UsersIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="9" cy="8" r="3.5" />
      <path d="M2 20c.8-3.5 3.7-5.5 7-5.5s6.2 2 7 5.5" strokeLinecap="round" />
      <circle cx="17" cy="9" r="2.5" />
      <path d="M16 14.5c2.5.2 4.7 1.7 5.5 4.5" strokeLinecap="round" />
    </svg>
  );
}
function DotIcon() {
  return (
    <svg width="6" height="6" viewBox="0 0 6 6" fill="currentColor">
      <circle cx="3" cy="3" r="3" />
    </svg>
  );
}
