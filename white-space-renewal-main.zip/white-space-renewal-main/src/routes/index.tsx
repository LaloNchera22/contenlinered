import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Red Social — Conecta, comparte, construye" },
      {
        name: "description",
        content:
          "Una red social minimalista para conectar, compartir y construir ideas.",
      },
    ],
  }),
  component: Index,
});

type Mode = "login" | "register";

function Index() {
  const [mode, setMode] = useState<Mode>("login");

  return (
    <main
      className="min-h-screen w-full bg-background text-foreground antialiased"
      style={{ fontFamily: "var(--font-sans)" }}
    >
      <div className="mx-auto flex min-h-screen w-full max-w-[1200px] flex-col px-6 sm:px-10">
        <Header />

        <section className="flex flex-1 items-center justify-center py-16">
          <div className="grid w-full grid-cols-1 gap-16 md:grid-cols-2 md:gap-24">
            <Brand />
            <AuthCard mode={mode} setMode={setMode} />
          </div>
        </section>

        <Footer />
      </div>
    </main>
  );
}

function Header() {
  return (
    <header className="flex items-center justify-between pt-8">
      <div className="flex items-center gap-2">
        <span
          aria-hidden
          className="inline-block h-2 w-2 rounded-full bg-foreground"
        />
        <span className="text-[13px] font-medium tracking-tight">
          Red Social
        </span>
      </div>
      <nav className="hidden items-center gap-7 text-[13px] text-[color:var(--subtle)] sm:flex">
        <a className="transition-colors hover:text-foreground" href="#about">
          Sobre
        </a>
        <a className="transition-colors hover:text-foreground" href="#privacy">
          Privacidad
        </a>
        <a className="transition-colors hover:text-foreground" href="#help">
          Ayuda
        </a>
      </nav>
    </header>
  );
}

function Brand() {
  return (
    <div className="flex flex-col justify-center">
      <p className="mb-6 text-[11px] uppercase tracking-[0.18em] text-[color:var(--subtle)]">
        v1.0 — Beta abierta
      </p>
      <h1 className="text-[44px] font-medium leading-[1.05] tracking-[-0.02em] sm:text-[56px]">
        Red Social.
      </h1>
      <p className="mt-5 max-w-md text-[15px] leading-relaxed text-[color:var(--subtle)]">
        Conecta. Comparte. Construye.
        <br />
        Un espacio limpio para tus ideas, sin ruido ni distracciones.
      </p>

      <ul className="mt-12 space-y-3 text-[13px] text-[color:var(--subtle)]">
        {[
          "Sin algoritmos opacos",
          "Privacidad por defecto",
          "Hecho para creadores",
        ].map((t) => (
          <li key={t} className="flex items-center gap-3">
            <span className="h-px w-6 bg-foreground/30" />
            {t}
          </li>
        ))}
      </ul>
    </div>
  );
}

function AuthCard({
  mode,
  setMode,
}: {
  mode: Mode;
  setMode: (m: Mode) => void;
}) {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col justify-center">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-8 inline-flex items-center gap-1 text-[13px]">
          <TabButton active={mode === "login"} onClick={() => setMode("login")}>
            Entrar
          </TabButton>
          <span className="px-2 text-[color:var(--subtle)]">·</span>
          <TabButton
            active={mode === "register"}
            onClick={() => setMode("register")}
          >
            Registrarse
          </TabButton>
        </div>

        <form
          className="space-y-6"
          onSubmit={(e) => {
            e.preventDefault();
            navigate({ to: "/home" });
          }}
        >
          {mode === "register" && (
            <Field
              label="Nombre"
              type="text"
              name="name"
              placeholder="Tu nombre"
            />
          )}
          <Field
            label="Email"
            type="email"
            name="email"
            placeholder="correo@ejemplo.com"
          />
          <Field
            label="Contraseña"
            type="password"
            name="password"
            placeholder="••••••••"
          />

          <button
            type="submit"
            className="group mt-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-foreground text-[13px] font-medium tracking-tight text-background transition-all duration-200 hover:opacity-90 active:scale-[0.99]"
          >
            {mode === "login" ? "Entrar" : "Crear cuenta"}
            <span
              aria-hidden
              className="translate-x-0 transition-transform duration-200 group-hover:translate-x-0.5"
            >
              →
            </span>
          </button>

          <p className="pt-2 text-center text-[12px] text-[color:var(--subtle)]">
            Al continuar aceptas nuestros{" "}
            <a className="underline-offset-4 hover:underline" href="#terms">
              términos
            </a>
            .
          </p>
        </form>
      </div>
    </div>
  );
}

function TabButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "relative px-1 py-1 transition-colors " +
        (active
          ? "text-foreground"
          : "text-[color:var(--subtle)] hover:text-foreground")
      }
    >
      {children}
      <span
        aria-hidden
        className={
          "absolute -bottom-0.5 left-0 h-px bg-foreground transition-all duration-300 " +
          (active ? "w-full" : "w-0")
        }
      />
    </button>
  );
}

function Field({
  label,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-[11px] uppercase tracking-[0.14em] text-[color:var(--subtle)]">
        {label}
      </span>
      <input
        {...props}
        className="block w-full border-0 border-b border-[color:var(--hairline)] bg-transparent pb-2 text-[14px] text-foreground placeholder:text-[color:var(--subtle)]/60 outline-none transition-colors focus:border-foreground"
      />
    </label>
  );
}

function Footer() {
  return (
    <footer className="flex items-center justify-between border-t border-[color:var(--hairline)] py-6 text-[12px] text-[color:var(--subtle)]">
      <span>© {new Date().getFullYear()} Red Social</span>
      <span className="hidden sm:inline">Hecho con calma.</span>
    </footer>
  );
}
